
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import logo from "@/assets/Screenshot_1.png";

export default function HomePage() {
  const navigate = useNavigate();
  return (
    <div className="p-6 space-y-6 text-center max-w-lg mx-auto">
      <img src={logo} alt="Colégio Scaranne" className="w-56 mx-auto" />
      <h1 className="text-2xl font-bold">Painel da Festa Junina</h1>
      <div className="space-y-3">
        <Button className="w-full" onClick={() => navigate("/venda")}>Registrar Venda</Button>
        <Button className="w-full" onClick={() => navigate("/checkin")}>Leitor de Ingressos</Button>
        <Button className="w-full" onClick={() => navigate("/relatorio")}>Relatório Administrativo</Button>
      </div>
    </div>
  );
}
