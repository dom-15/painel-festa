
import React, { useState } from 'react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import logo from "@/assets/Screenshot_1.png";

export default function VendaIngressosPage() {
  const [aluno, setAluno] = useState("");
  const [vendedor, setVendedor] = useState("");
  const [quantidade, setQuantidade] = useState(1);
  const [forma, setForma] = useState([]);
  const [valorRecebido, setValorRecebido] = useState(0);
  const [mensagem, setMensagem] = useState("");

  const registrar = async () => {
    try {
      const res = await fetch("/venda", {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          aluno,
          vendedor,
          quantidade: parseInt(quantidade),
          forma_pagamento: forma,
          valor_recebido: parseFloat(valorRecebido)
        })
      });
      const json = await res.json();
      if (res.ok) setMensagem(`Ingressos gerados: ${json.codigos.join(", ")}`);
      else setMensagem("Erro: " + json.detail);
    } catch {
      setMensagem("Erro de conexão.");
    }
  };

  const toggleForma = (f) => {
    setForma(prev => prev.includes(f) ? prev.filter(v => v !== f) : [...prev, f]);
  };

  return (
    <div className="p-4 space-y-4 max-w-md mx-auto text-center">
      <img src={logo} alt="Colégio Scaranne" className="w-48 mx-auto" />
      <h1 className="text-xl font-bold">Registrar Venda</h1>
      <Input value={aluno} onChange={(e) => setAluno(e.target.value)} placeholder="Nome do aluno" />
      <Input value={vendedor} onChange={(e) => setVendedor(e.target.value)} placeholder="Nome do vendedor" />
      <Input value={quantidade} onChange={(e) => setQuantidade(e.target.value)} type="number" placeholder="Quantidade de ingressos" />
      <Input value={valorRecebido} onChange={(e) => setValorRecebido(e.target.value)} type="number" placeholder="Valor recebido" />
      <div className="flex justify-center gap-2">
        {["dinheiro", "pix", "cartao"].map(f => (
          <Button key={f} variant={forma.includes(f) ? "default" : "outline"} onClick={() => toggleForma(f)}>{f}</Button>
        ))}
      </div>
      <Button onClick={registrar}>Registrar Venda</Button>
      <p className="text-sm text-gray-700 whitespace-pre-line">{mensagem}</p>
    </div>
  );
}
